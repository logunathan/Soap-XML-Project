<?php

  /* //Running Example

//Create the client object
$soapclient = new SoapClient('http://www.webservicex.net/globalweather.asmx?WSDL');

//Use the functions of the client, the params of the function are in 
//the associative array
$params = array('CountryName' => 'Spain', 'CityName' => 'Alicante');
$response = $soapclient->getWeather($params);

var_dump($response);*/


$client = new SOAPClient(
    'https://ecomm.thlrentals.com/testB2B/THLRentals.OTA.Utils/Aurora_OTA.asmx?WSDL',
    array(
        'location' => 'https://ecomm.thlrentals.com/testB2B/THLRentals.OTA.Utils/Aurora_OTA.asmx?WSDL',
        'trace' => 1,
		'soap_version' => SOAP_1_1,
        'style' => SOAP_RPC,
        'use' => SOAP_ENCODED,
    )
);

/*$request = '<THL_LoginOkRQ EchoToken="Token" Version="1.1" xmlns="http://www.opentravel.org/OTA/2003/05"><email>driveacampervan@gmail.com</email> 
<IsAgent>true</IsAgent> 
<password>davido</password> 
</THL_LoginOkRQ>';*/
$request =array('email'=>'driveacampervan@gmail.com','IsAgent'=>true,'password'=>'davido');
$result = array();

//$params = array("THL_LoginOkRQ" => $request);
$params = array (
  'THL_LoginOkRQ' => $request,
  "OutPut" => NULL,
  "ErrorMsg" => NULL
);

try {
    $result = $client->__soapCall('LoginOk', array(array('THL_LoginOkRQ' => $request)));
} catch (SoapFault $e) {
    echo "SOAP Fault: ".$e->getMessage()."<br />\n";
}

echo "<pre>";
//echo var_dump($client->__getFunctions())."\n";
//echo "<br>";
echo htmlspecialchars($client->__getLastRequestHeaders())."\n";
echo htmlspecialchars($client->__getLastRequest())."\n";
echo "Response:\n".htmlspecialchars($client->__getLastResponseHeaders())."\n";
echo htmlspecialchars($client->__getLastResponse())."\n";
echo "</pre>"; 

var_dump($result);

?>
