<?php
$wsdl   = "https://ecomm.thlrentals.com/testB2B/THLRentals.OTA.Utils/Aurora_OTA.asmx?WSDL";

$URL = 'https://ecomm.thlrentals.com/testB2B/THLRentals.OTA.Utils/Aurora_OTA.asmx';


$client = new SoapClient(null, array(
    'location' => $URL,
    'uri'      => "http://www.thlrentals.com/Aurora/OTA/",
    'trace'    => true,
    ));
	$params = new stdClass;
$params->THL_LoginOkRQ = new stdClass;
$params->THL_LoginOkRQ->email = 'driveacampervan@gmail.com';
$params->THL_LoginOkRQ->IsAgent = true;
$params->THL_LoginOkRQ->password= 'davido';

$user_param = array ('email' => 'driveacampervan@gmail.com','IsAgent'=> 'true','password' => 'davido');
//$service_param = array ("THL_LoginOkRQ" => $user_param);
//$service_param=new SoapParam($user_param->THL_LoginOkRQ,'ns1:THL_LoginOkRQ');
//$service_param = array ('THL_LoginOkRQ' => $user_param);
$paramval= new SoapVar('<THL_LoginOkRQ EchoToken="Token" Version="1.1" xmlns="http://www.opentravel.org/OTA/2003/05"><email>driveacampervan@gmail.com</email> 
<IsAgent>true</IsAgent> 
<password>davido</password> 
</THL_LoginOkRQ>', XSD_ANYXML);
try{
//$return = $client->__soapCall("LoginOk",$service_param,array('soapaction' => 'http://www.thlrentals.com/Aurora/OTA/LoginOk'));
//$return = $client->__soapCall("LoginOk",array($params),array("soapaction" => "http://www.thlrentals.com/Aurora/OTA/LoginOk"));

 // $response = $client->LoginOk(new SoapParam($params->THL_LoginOkRQ, 'ns1:THL_LoginOkRQ'));
 
//$response = $client->LoginOk(array('trx' => $params));  
  $return = $client->__soapCall("LoginOk",
 array(new SoapParam($params->THL_LoginOkRQ, 'ns1:THL_LoginOkRQ')),array('soapaction' => "http://www.thlrentals.com/Aurora/OTA/LoginOk"));

   
}catch (SoapFault $e) {
    echo "Error: {$e}";
}
echo "<hr>Last Request";
echo '</br>';
echo htmlspecialchars($client->__getLastRequest());
echo '</br>';
echo "<hr>Last Response";
echo '</br>';
echo htmlspecialchars($client->__getLastResponse());


/*
   //Running Example

//Create the client object
$soapclient = new SoapClient('http://www.webservicex.net/globalweather.asmx?WSDL');

//Use the functions of the client, the params of the function are in 
//the associative array
$params = array('CountryName' => 'Spain', 'CityName' => 'Alicante');
$response = $soapclient->getWeather($params);

var_dump($response);
*/

?>